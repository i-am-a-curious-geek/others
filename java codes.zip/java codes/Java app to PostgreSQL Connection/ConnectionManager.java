import java.sql.*;

public class ConnectionManager {

    public static void main(String args[]) {
        String host = "127.0.0.1";
        String port = "5432";
        String dbName = "postgis20";
        String username = "postgres";
        String password = "password";

        try {
            Connection connection = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            connection = DriverManager.getConnection("jdbc:postgresql://" + host + ":" + port + "/" + dbName, username, password);

            String sql = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features FROM (SELECT 'Feature' As type, ST_AsGeoJSON(lg.geom)::json As geometry, row_to_json(lp) As properties FROM regions As lg INNER JOIN (SELECT gid FROM regions) As lp ON lg.gid = lp.gid ) As f)  As fc;";
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                String geojson = rs.getString(1);
                System.out.println(geojson);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}