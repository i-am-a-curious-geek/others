import au.com.bytecode.opencsv.CSVReader;
import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.util.*;
import java.util.zip.*;
import project.entity.Student;

public class Bootstrap {
  
  public static void DropAllTables() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      ps = con.prepareStatement("drop table if exists rejected_bids");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists section_student");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists bidding_round");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists bid");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists course_completed");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists pre_req");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists section");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists course");
      ps.executeUpdate();
      ps = con.prepareStatement("drop table if exists student");
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // Drop all tables

  public static void createTables() {
    createStudentTable();
    createCourseTable();
    createPreReqTable();
    createCourseCompletedTable();
    createSectionTable();
    createBidTable();
    createBiddingRoundTable();
    createSectionStudentTable();
    createRejectedBidsTable();
    createBidRound2Table();
  }

  public static void createStudentTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table student(userID varchar(20) not null,password varchar(30) not null,name varchar(100) not null,school varchar(10) not null,eDollar double not null,constraint student_pk primary key(userID))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createCourseTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table course(course varchar(10) not null,school varchar(10) not null,title varchar(100)  not null,description varchar(1000),examDate date,examStart time,examEnd time,constraint course_pk primary key(course))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createPreReqTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table pre_req(course varchar(10) not null,preReq varchar(10) not null,constraint pre_req_pk primary key(course, preReq),constraint pre_req_fk1 foreign key(course) references course(course),constraint pre_req_fk2 foreign key(preReq) references course(course))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createCourseCompletedTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table course_completed(userID varchar(20) not null,course varchar(10) not null,constraint course_completed_pk primary key(userID, course),constraint course_completed_fk1 foreign key(userID) references student(userID),constraint course_completed_fk2 foreign key(course) references course(course))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createSectionTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table section(course varchar(10) not null,section varchar(4) not null,day int,start time,end time,instructor varchar(100),venue varchar(50),size int,constraint section_pk primary key(section, course),constraint section_fk1 foreign key(course) references course(course))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createBidTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table bid(userID varchar(20) not null,amount double not null,course varchar(10) not null,section varchar(4) not null,constraint bid_pk primary key(userID, section, course),constraint bid_fk1 foreign key(userID) references student(userID),constraint bid_fk2 foreign key(section, course) references section(section, course))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } //close createBidTable

  public static void createBiddingRoundTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table bidding_round(round_no int not null,status varchar(20) not null,constraint bidding_round_pk primary key(round_no))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } //close createBiddingRoundTable

  public static void createSectionStudentTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table section_student(userID varchar(20) not null,course varchar(10) not null,section varchar(4) not null,amount double not null,round int not null,constraint section_student_pk primary key(userID, course, section))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createSectionStudentTable

  public static void createRejectedBidsTable() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table rejected_bids(userID varchar(20) not null,course varchar(10) not null,section varchar(4) not null,amount double not null,round int not null,constraint rejected_bids_pk primary key(userID, course, section))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createRejectedBidsTable
  
  public static void createBidRound2Table() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      con = ConnectionManager.getConnection();
      String sql = "create table bid_round_2 (userID varchar(20) not null,course varchar(10) not null,section varchar(4) not null,amount double not null,round int not null,constraint rejected_bids_pk primary key(userID, course, section))";
      ps = con.prepareStatement(sql);
      ps.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      ConnectionManager.close(con, ps, rs);
    } // finally
  } // createBidRound2Table

  public static void loadStudents(ZipInputStream zin, BufferedReader br) throws ZipException, IOException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithStudentErrors();
    int lineCounter = 1;
    while ((zipentry = zin.getNextEntry()) != null) {
      // get name of the text file in the zip file
      // assume we know all the names of the text file
      String textFileName = zipentry.getName();
      if (textFileName.equals("student.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          if (!errorRecord) {
            String userID = nextLine[0].trim();
            String password = nextLine[1].trim();
            String name = nextLine[2].trim();
            String school = nextLine[3].trim();
            double eDollars = Double.parseDouble(nextLine[4].trim());
            // insert values into SQL database     
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into student values(?,?,?,?,?)");
              // mySQL starts from index 1
              ps.setString(1, userID);
              ps.setString(2, password);
              ps.setString(3, name);
              ps.setString(4, school);
              ps.setDouble(5, eDollars);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();
            } catch (SQLException e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            }// end SQL database
          }// close if (not errorRecord) 
        } // end while ((nextLine = csvReader.readNext()) != null)
      } //end if
    }// end while(e.hasMoreElements())
  } // loadStudents()

  public static void loadCourses(ZipInputStream zin, BufferedReader br) throws ZipException, IOException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithCourseErrors();
    int lineCounter = 1;
    while ((zipentry = zin.getNextEntry()) != null) {
      // get name of the text file in the zip file
      // assume we know all the names of the text file
      String textFileName = zipentry.getName();
      if (textFileName.equals("course.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          if (!errorRecord) {
            String courseCode = nextLine[0].trim();
            String school = nextLine[1].trim();
            String title = nextLine[2].trim();
            String description = nextLine[3].trim();
            String examDate = nextLine[4].trim();
            String examStart = nextLine[5].trim();
            String examEnd = nextLine[6].trim();
            // insert values into SQL database            
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into course values(?,?,?,?,?,?,?)");
              // mySQL starts from index 1
              ps.setString(1, courseCode);
              ps.setString(2, school);
              ps.setString(3, title);
              ps.setString(4, description);
              ps.setString(5, examDate);
              ps.setString(6, examStart);
              ps.setString(7, examEnd);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();
            } catch (SQLException e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            } // end SQL database   
          } //end if(not errorRecord)
        }// end while-loop (csvReader)				} 
      } // end if-block 
    } // end while-loop          
  } // loadCourses()

  public static void loadSections(ZipInputStream zin, BufferedReader br) throws ZipException, IOException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithSectionErrors();
    int lineCounter = 1;
    while ((zipentry = zin.getNextEntry()) != null) {
      // get name of the text file in the zip file
      // assume we know all the names of the text file
      String textFileName = zipentry.getName();
      if (textFileName.equals("section.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          if (!errorRecord) {
            String courseCode = nextLine[0].trim();
            String section = nextLine[1].trim();
            int day = Integer.parseInt(nextLine[2].trim());
            String start = nextLine[3].trim();
            String end = nextLine[4].trim();
            String instructor = nextLine[5].trim();
            String venue = nextLine[6].trim();
            int size = Integer.parseInt(nextLine[7].trim());
            /*
             Scanner sc = new Scanner(inputstream);
             sc.useDelimiter(",|\r\n");
             int counter = 0;
             while (sc.hasNext()) {
             for (; counter < 8; counter++) { // to skip the heading
             sc.next();
             } // heading is skipped
             String courseCode = sc.next();
             String section = sc.next();
             int day = Integer.parseInt(sc.next());
             String start = sc.next();
             String end = sc.next();
             String instructor = sc.next();
             String venue = sc.next();
             int size = Integer.parseInt(sc.next());
             */
            // insert values into SQL database         
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into section values(?,?,?,?,?,?,?,?)");
              // mySQL starts from index 1
              ps.setString(1, courseCode);
              ps.setString(2, section);
              ps.setInt(3, day);
              ps.setString(4, start);
              ps.setString(5, end);
              ps.setString(6, instructor);
              ps.setString(7, venue);
              ps.setInt(8, size);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();
            } catch (SQLException e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            }
            // end SQL database  
          } //end if (not errorRecord)
        }// end while-loop (csvReader) 				} 
      } // end if-block 
    } // end while-loop  
  } // loadSections()

  public static void loadPreReq(ZipInputStream zin, BufferedReader br) throws ZipException, IOException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithPreReqErrors();
    int lineCounter = 1;
    while ((zipentry = zin.getNextEntry()) != null) {
      // get name of the text file in the zip file
      // assume we know all the names of the text file
      String textFileName = zipentry.getName();
      if (textFileName.equals("prerequisite.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          if (!errorRecord) {
            String courseCode = nextLine[0].trim();
            String preReqCode = nextLine[1].trim();
            // insert values into SQL database             
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into pre_req values(?,?)");
              // mySQL starts from index 1
              ps.setString(1, courseCode);
              ps.setString(2, preReqCode);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();
            } catch (SQLException e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            }
            // end SQL database
          } // end if (not errorRecord)
        }// end while-loop (csvReader) 				} 
      } // end if-block 
    } // end while-loop     
  } // loadPreReq

  public static void loadCoursesCompleted(ZipInputStream zin, BufferedReader br) throws ZipException, IOException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithCourseCompletedErrors();
    int lineCounter = 1;

    // get name of the text file in the zip file
    // assume we know all the names of the text file                                                                           
    while ((zipentry = zin.getNextEntry()) != null) {
      String textFileName = zipentry.getName();
      if (textFileName.equals("course_completed.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          if (!errorRecord) {
            String username = nextLine[0].trim();
            String code = nextLine[1].trim();
            // insert values into SQL database             
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into course_completed values(?,?)");
              // mySQL starts from index 1
              ps.setString(1, username);
              ps.setString(2, code);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();
            } catch (SQLException e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            }
            // end SQL database  
          }// end if (not errorRecord)
        }// end while-loop (csvReader)				} 
      } // end if-block 
    } // end while-loop     
  } // loadCoursesCompleted()

  public static void loadBids(ZipInputStream zin, BufferedReader br) throws ZipException, IOException, ParseException {
    ZipEntry zipentry = null;
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Integer> linesWithErrors = DataValidation.getLineNumbersWithBidErrors();
    int lineCounter = 1;

    while ((zipentry = zin.getNextEntry()) != null) {
      String textFileName = zipentry.getName();
      if (textFileName.equals("bid.csv")) {
        CSVReader csvReader = new CSVReader(br, ',', '"', 1);
        String[] nextLine;
        while ((nextLine = csvReader.readNext()) != null) {
          lineCounter++;
          boolean errorRecord = false;
          for (int lineNo : linesWithErrors) {
            if (lineNo == lineCounter) {
              errorRecord = true;
            }
          }
          //try{
          if (!errorRecord) {
            String userID = nextLine[0].trim();
            double amount = Double.parseDouble(nextLine[1].trim());
            String code = nextLine[2].trim();
            String section = nextLine[3].trim();
            // insert values into SQL database     
            try {
              con = ConnectionManager.getConnection();
              ps = con.prepareStatement("insert into bid values(?,?,?,?)");
              // mySQL starts from index 1
              ps.setString(1, userID);
              ps.setDouble(2, amount);
              ps.setString(3, code);
              ps.setString(4, section);
              // insert statement changes database
              // therefore use executeUpdate
              ps.executeUpdate();

              //deduct the amount from the student
              Student student = StudentDAO.retrieveStudent(userID);
              double newBalance = student.getEDollars() - amount;
              ps = con.prepareStatement("update student set eDollar=? where userID = ?");
              ps.setDouble(1, newBalance);
              ps.setString(2, userID);
              ps.executeUpdate();
            } catch (Exception e) {
              e.printStackTrace();
            } finally {
              ConnectionManager.close(con, ps, rs);
            }
            // end SQL database  
          } // end if (not errorRecord)
          //}catch(NumberFormatException nfe){

          //}
        }// end while-loop (csvReader) 				} 
      } // end if-block 
    } // end while-loop  
  } // loadBids()
} // end class