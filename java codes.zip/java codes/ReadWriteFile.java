import java.io.*;
import java.util.*;

public class ReadWriteFile {
	public static void main(String args[]) {
		try{
			File file = new File("data.txt");
			
			if (!file.exists()) {
				PrintStream writer = new PrintStream(new FileOutputStream("data.txt", true));
				writer.println(2); // write to file
				writer.close();
			} else {
				Scanner fIn = new Scanner(file);

				while (fIn.hasNext()) {
					String curLine = fIn.nextLine();
					System.out.println(curLine);
				}	
				fIn.close();
			}
		} 
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
