package dao;

import au.com.bytecode.opencsv.CSVReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DataCleaner {

    static Connection con = null;
    static PreparedStatement ps = null;
    static ResultSet rs = null;

    public static void loadFileData(File file) throws Exception {
        Scanner sc = new Scanner(file);
        con = ConnectionManager.getConnection();
        
        while (sc.hasNext()) {            
            try {
                String line = sc.nextLine();
                line = line.substring(0, line.length() - 1);

                System.out.println(line);
                ps = con.prepareStatement("INSERT INTO `crime_data` (`id`, `CrimeDateTime`, `CrimeCode`, `Location`, `Description`, `Weapon`, `Post`, `District`, `Neighborhood`, `Lat`, `Long`, `Incidents`) VALUES " + line);
                ps.executeUpdate();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }            
        }
        
        ConnectionManager.close(con, ps, rs);
    }

    public static void main(String[] args) throws Exception {

        File file = new File("C:\\Users\\lenovo\\Desktop\\DataCleaner\\src\\dao\\sql_queries.txt");
        loadFileData(file);

    }

}
